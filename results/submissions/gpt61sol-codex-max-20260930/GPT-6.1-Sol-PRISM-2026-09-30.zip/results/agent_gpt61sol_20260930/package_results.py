import json, hashlib, datetime, shutil, gzip, zipfile, subprocess
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from harness.submit import build_submission, verify_submission, benchmark_fingerprint

HERE = Path(__file__).resolve().parent
provenance = json.loads((HERE / "provenance.json").read_text(encoding="utf-8"))
for task, digest in provenance["first_attempt_sha256"].items():
    assert (
        hashlib.sha256((HERE / "first_attempt" / f"{task}.bsl").read_bytes()).hexdigest() == digest
    )
rows = {}
submissions = []
summaries = {}
for stage in ("first", "repaired"):
    passed = total = solved = measured = applicable = 0
    for cat in ("A", "B"):
        name = f"experiment_{cat}_20260930_gpt61sol_codex_{stage}"
        auto = ROOT / "results/auto" / f"{name}_auto_l1.json"
        data = json.loads(auto.read_text(encoding="utf-8"))
        sp, submission = build_submission(
            auto, created=datetime.datetime.now(datetime.timezone.utc).isoformat()
        )
        assert verify_submission(sp)["compatible"]
        submissions.append(sp)
        for task in data["tasks"]:
            r = task["runs"][0]
            m = r["detail"]["M"]
            p = m.get("passed", 0)
            n = m.get("total", 0)
            passed += p
            total += n
            solved += p == n and n > 0
            measured += r["detail"]["coverage"]["measured"]
            applicable += r["detail"]["coverage"]["applicable"]
            rows.setdefault(task["task_id"], {})[stage] = {
                "passed": p,
                "total": n,
                "scores": r["scores"],
            }
    summaries[stage] = {
        "solved": solved,
        "tasks": 35,
        "passed": passed,
        "tests": total,
        "measured_axes": measured,
        "applicable_axes": applicable,
    }
assert summaries["first"]["passed"] == 166 and summaries["repaired"]["passed"] == 174
summary = {
    "model": "gpt-6.1-sol",
    "reasoning_effort": "max",
    "protocol": "Codex desktop agent, first attempts and repairs reported separately",
    "benchmark_commit": provenance["benchmark_commit"],
    "compat_hash": benchmark_fingerprint(),
    "summaries": summaries,
    "tasks": rows,
    "publication_status": "prepared locally; Git Credential Manager has no noninteractive GitHub credential",
    "validation": {
        "pytest": {"passed": 468, "skipped": 23},
        "prism_check_original": "contracts pass; execution tools skipped in unadapted Windows mode",
    },
}
check = ROOT / "work/reports/check-windows.json"
if check.exists():
    summary["validation"]["prism_check_windows"] = json.loads(check.read_text(encoding="utf-8"))
(HERE / "summary.json").write_text(
    json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
)
lines = [
    "# GPT-6.1 Sol в PRISM",
    "",
    "Проверено 30 сентября 2026 года. Модель текущего Codex-сеанса: `gpt-6.1-sol`, reasoning effort: `max` (подтверждено локальными метаданными turn_context).",
    "",
    "| Этап | Полностью решено | Пройдено тестов | Измерено осей SMOP |",
    "|---|---:|---:|---:|",
]
for stage, label in [("first", "Первая попытка"), ("repaired", "После исправления трёх решений")]:
    s = summaries[stage]
    lines.append(
        f"| {label} | {s['solved']}/35 | {s['passed']}/{s['tests']} | {s['measured_axes']}/{s['applicable_axes']} |"
    )
lines += [
    "",
    "Для испытания модели основной результат — первая попытка: 32/35 задач (91,4%), 166/174 тестов (95,4%). Исправленные решения показывают результат агента после обратной связи; их следует публиковать отдельным этапом.",
    "",
    "Решения всех 35 задач были сохранены и зафиксированы SHA-256 до получения результатов скрытых тестов. До написания решений агент прочитал условия task.yaml и схемы config_spec.yaml. Эталонные решения и исходники скрытых тестов агенту не показывались. Затем штатный проверяющий код PRISM исполнил скрытые проверки. Позднее дополнительный self-check читает эталоны внутри процесса проверки и выводит только статусы.",
    "",
    "Этот запуск использует одну общую беседу Codex и доступные агенту инструменты. Он отличается от стандартного generate через API и требует отдельного обозначения в публикации. Нельзя заменять им стандартную строку GPT-6.1 Sol в лидерборде без согласования условий с мейнтейнером.",
    "",
    "Измерены S и M для обеих категорий, O для корректных решений категории A. Для B оптимальность и доказательство обращений к данным по SDBL не измерены: O и P записаны как null. Полный рейтинг SMOP и сравнение со строками с полным охватом не установлены. Значение Q=10 после исправлений относится только к измеренным осям.",
    "",
    "API temperature, seed, лимит ответа, фактические токены и цена этого сеанса недоступны. Нули в этих полях экспериментальных JSON — обязательные значения по умолчанию схемы PRISM, их нельзя интерпретировать как измеренные нулевые расходы. provenance.json и agent_provenance явно фиксируют отсутствие измерения.",
    "",
    "PRISM 1.10.0; исходный commit: `"
    + provenance["benchmark_commit"]
    + "`. Условия, тесты и правила метрики в исходном репозитории сохранены. Compat hash: `"
    + benchmark_fingerprint()
    + "`.",
    "",
    "Среда: Windows, Python 3.12.14, OneScript 2.0.1 для Windows, BSL LS 0.29.0, Java JBR 25.0.3, 1С 8.3.27.2214. Windows-адаптер запускает собственные решения локально и использует штатные скореры. На OneScript есть сторож по настенному времени, квота процессорного времени Linux не воспроизводится. Для каждой задачи B создана отдельная синтетическая файловая база внутри work; рабочие базы не используются.",
    "",
    "Ошибки первых попыток:",
    "",
    "- A5: Структура.Свойство при отсутствующем ключе заменяло счетчик на Неопределено; исправлена инициализация счетчика.",
    "- B17: агрегирование запроса приводило к взаимозачету долга и авансов; исправлен выбор остатков с сохранением измерения Договор и последующее суммирование положительных остатков.",
    "- B19: платформа запрещает В ИЕРАРХИИ внутри агрегатной функции; отбор перенесен в WHERE двух ветвей дебета и кредита.",
    "",
    "32 решения после первого прогона сохранены без изменений; повторно проверены только A5, B17 и B19. Первые попытки в first_attempt неизменны.",
    "",
    "Проверки среды:",
    "",
    "- Тесты проекта: 468 passed, 23 skipped. Это отдельный результат от 174 тестов решений.",
    "- Штатный prism check: контракты и банк задач согласованы; в исходном Windows-режиме исполняемые срезы пропущены из-за путей Linux/Docker. Дополнительный check_windows запускает эталоны и якоря через Windows-адаптер; его итог указан в summary.json и evidence/check-windows.log.",
    "",
    "Все четыре пакета submission созданы штатным harness.submit.build_submission и прошли verify_submission с совпадением отпечатка текущего бенчмарка. Это проверка версии, она не означает равенства протокола агентного запуска и стандартного API-прогона.",
    "",
    "Для размещения: приложить два пакета *_first_submission.json и этот отчет к PR в genlab-1c/prism; исправленные пакеты приложить отдельно как работу агента после обратной связи. Вход GitHub через Git Credential Manager отсутствует; публикация не выполнялась. Порядок приема описан в [CONTRIBUTING.md](https://github.com/genlab-1c/prism/blob/main/CONTRIBUTING.md).",
    "",
    "Для воспроизведения на Windows: uv sync; установить OneScript 2.0.1 и BSL LS 0.29.0 в tools; обеспечить Java 21+ и 1С 8.3.27.2214. Указанные в windows_adapter.py пути настроить под свою установку. Подготовить пустую синтетическую конфигурацию через prepare_onec.py, затем score_initial.py A и score_initial.py B; score_repairs.py проверяет три исправления. Freeze_initial.py повторно запускать нельзя: он защищен от перезаписи первых попыток.",
    "",
    "| Задача | Первая попытка | После исправлений |",
    "|---|---:|---:|",
]
for task in sorted(rows, key=lambda t: (t[0], int(t[1:]))):
    a = rows[task]["first"]
    b = rows[task]["repaired"]
    lines.append(f"| {task} | {a['passed']}/{a['total']} | {b['passed']}/{b['total']} |")
(HERE / "README.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
evidence = HERE / "evidence"
evidence.mkdir(exist_ok=True)
for name in (
    "pytest-original.xml",
    "pytest-original.log",
    "doctor-original.log",
    "check-original.log",
    "score-first-A.log",
    "score-first-B.log",
    "score-repaired.log",
    "check-windows.log",
    "check-windows.json",
    "check-canonical-B.json",
    "check-canonical-B.log",
):
    source = ROOT / "work/reports" / name
    if source.exists():
        shutil.copyfile(source, evidence / name)
# Only text execution evidence; no infobases, .cf/.dt files, platform distributions, or secrets.
archive_members = []
for stage in ("first", "repaired"):
    for cat in ("A", "B"):
        run_root = ROOT / "work" / f"experiment_{cat}_20260930_gpt61sol_codex_{stage}"
        for p in run_root.rglob("*"):
            if not p.is_file():
                continue
            keep = p.name in (
                "bsl-json.json",
                "result.txt",
                "native-result.json",
                "create.log",
                "load.log",
                "upd.log",
                "check.log",
                "check.rc",
                "enterprise.rc",
            ) or p.name.endswith((".stdout.log", ".stderr.log"))
            if keep:
                archive_members.append(p)
with zipfile.ZipFile(
    HERE / "execution_evidence.zip", "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6
) as z:
    for p in archive_members:
        z.write(p, p.relative_to(ROOT).as_posix())
print(
    json.dumps(
        {
            "summaries": summaries,
            "compatible_submissions": [p.relative_to(ROOT).as_posix() for p in submissions],
            "evidence_files": len(archive_members),
        },
        ensure_ascii=False,
        indent=2,
    )
)
