import sys, json, datetime, hashlib, subprocess
from pathlib import Path
from shutil import copyfile

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from harness.loaders import load_tasks
from harness.generate.hashing import compute_hash
from harness.generate.results import RunResult, TaskResult, ExperimentResult

HERE = Path(__file__).resolve().parent
if (HERE / "provenance.json").exists():
    raise SystemExit("First attempts are already frozen; refusing to overwrite them")
first = HERE / "first_attempt"
first.mkdir(exist_ok=True)
files = sorted((HERE / "solutions").glob("*.bsl"))
hashes = {}
for file in files:
    copyfile(file, first / file.name)
    hashes[file.stem] = hashlib.sha256(file.read_bytes()).hexdigest()
now = datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=3))).isoformat()
metadata = {
    "model": "gpt-6.1-sol",
    "reasoning_effort": "max",
    "identity_evidence": "current Codex desktop turn_context",
    "evaluation_mode": "Codex agent, one session, tools available, all first solutions frozen before hidden test results",
    "benchmark_commit": subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
    ).strip(),
    "benchmark_version": "1.10.0",
    "created_at": now,
    "first_attempt_sha256": hashes,
    "canonical_solutions_read": False,
    "hidden_tests_read_before_generation": False,
    "sampling_temperature": None,
    "sampling_seed": None,
    "max_output_tokens": None,
    "provider_usage": None,
    "provider_cost": None,
    "schema_placeholders": "Numeric zero defaults in PRISM generation schema denote unavailable sampling and billing metadata; not measured zero costs",
    "limitations": [
        "single shared agent context; not standard API generation protocol",
        "OneScript Windows wall watchdog, no CPU quota",
        "native Windows 1C 8.3.27.2214 replaces Docker training platform",
        "B optimization and platform journal evidence not measured",
    ],
}
(HERE / "provenance.json").write_text(
    json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
)
tasks = load_tasks()
for category in ("A", "B"):
    records = []
    for task in sorted([t for t in tasks if t.category == category], key=lambda t: int(t.id[1:])):
        code = (first / f"{task.id}.bsl").read_text(encoding="utf-8")
        run = RunResult(
            run_index=1,
            response=code,
            response_hash=compute_hash(code),
            reasoning_effort="max",
            generated_at=datetime.datetime.fromtimestamp(
                (HERE / "solutions" / f"{task.id}.bsl").stat().st_mtime, datetime.timezone.utc
            ).isoformat(),
            provenance="Codex desktop agent; first attempt from prompt and metadata only; API sampling and usage unavailable",
        )
        records.append(
            TaskResult(
                task_id=task.id,
                task_name=task.name,
                model_id="gpt-6.1-sol-codex-max",
                model_name="GPT-6.1 Sol (Codex, max)",
                context_loaded=category == "B",
                context_objects=task.expected_objects if category == "B" else [],
                runs=[run],
            )
        )
    name = f"experiment_{category}_20260930_gpt61sol_codex_first"
    experiment = ExperimentResult(
        experiment_name=name,
        category=category,
        timestamp=now,
        models_used=["GPT-6.1 Sol (Codex, max)"],
        tasks_count=len(records),
        runs_per_task=1,
        task_results=records,
    )
    data = experiment.model_dump()
    data["agent_provenance"] = metadata
    (ROOT / "results" / f"{name}.json").write_text(
        json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
    )
print("Frozen", len(files), "solutions; wrote two initial PRISM experiments and provenance.")
