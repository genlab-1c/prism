import json
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from windows_adapter import install, ROOT, run_onec

install()
from harness.loaders import load_tasks

base = ROOT / "work/check_windows_B"


def verify(task):
    candidates = list(
        (ROOT / "work/check_windows_temp").glob(f"prism_check_*/{task.id}_cm/**/native-result.json")
    )
    if candidates:
        path = max(candidates, key=lambda p: p.stat().st_mtime)
        result = json.loads(path.read_text(encoding="utf-8"))
    else:
        result = run_onec(
            task.canonical.read_text(encoding="utf-8-sig"),
            task.dir,
            base / task.id,
            task.entry_point_patterns,
        ).model_dump()
    ok = (
        result["status"] == "ok"
        and result["total"] > 0
        and result["passed"] == result["total"]
        and not result["compile_error_lines"]
    )
    return {"task_id": task.id, "ok": ok, "result": result}


tasks = sorted([t for t in load_tasks() if t.category == "B"], key=lambda t: int(t.id[1:]))
with ThreadPoolExecutor(max_workers=4) as pool:
    results = list(pool.map(verify, tasks))
report = {
    "canonical_B_correctness_ok": all(r["ok"] for r in results),
    "results": results,
    "P_O_measured": False,
}
(ROOT / "work/reports/check-canonical-B.json").write_text(
    json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
)
for r in results:
    print(r["task_id"], r["ok"], r["result"]["passed"], r["result"]["total"], flush=True)
raise SystemExit(0 if report["canonical_B_correctness_ok"] else 1)
