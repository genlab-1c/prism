import datetime, hashlib, json, zipfile, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from harness.submit import build_submission, verify_submission

HERE = Path(__file__).resolve().parent
for cat in ("A", "B"):
    p = ROOT / "results" / f"experiment_{cat}_20260930_gpt61sol_codex_repaired.json"
    d = json.loads(p.read_text(encoding="utf-8"))
    for task in d["task_results"]:
        if task["task_id"] in ("A5", "B17", "B19"):
            task["runs"][0]["generated_at"] = datetime.datetime.fromtimestamp(
                (HERE / "solutions" / f"{task['task_id']}.bsl").stat().st_mtime,
                datetime.timezone.utc,
            ).isoformat()
    d["timestamp"] = datetime.datetime.fromtimestamp(
        p.stat().st_mtime, datetime.timezone.utc
    ).isoformat()
    p.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
for cat in ("A", "B"):
    for stage in ("first", "repaired"):
        auto = (
            ROOT / "results/auto" / f"experiment_{cat}_20260930_gpt61sol_codex_{stage}_auto_l1.json"
        )
        package, _ = build_submission(
            auto, created=datetime.datetime.now(datetime.timezone.utc).isoformat()
        )
        assert verify_submission(package)["compatible"]
allowed = {".py", ".md", ".json", ".bsl", ".log", ".xml", ".zip"}
files = [
    p
    for p in HERE.rglob("*")
    if p.is_file() and p.suffix.lower() in allowed and "__pycache__" not in p.parts
]
files.append(ROOT / "LICENSE")
for cat in ("A", "B"):
    for stage in ("first", "repaired"):
        name = f"experiment_{cat}_20260930_gpt61sol_codex_{stage}"
        files += [
            ROOT / "results" / f"{name}.json",
            ROOT / "results/auto" / f"{name}_auto_l1.json",
            ROOT / "results/submissions" / f"{name}_submission.json",
        ]
files = sorted(set(files))
manifest = {
    p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in files
}
out = ROOT / "results/GPT-6.1-Sol-PRISM-2026-09-30.zip"
with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for p in files:
        z.write(p, p.relative_to(ROOT).as_posix())
    z.writestr("SHA256_MANIFEST.json", json.dumps(manifest, ensure_ascii=False, indent=2))
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    for name, digest in manifest.items():
        assert hashlib.sha256(z.read(name)).hexdigest() == digest
    assert not any(
        name.lower().endswith((".1cd", ".cf", ".dt", ".exe", ".dll", ".jar", ".env"))
        for name in z.namelist()
    )
    with zipfile.ZipFile(HERE / "execution_evidence.zip") as inner:
        assert inner.testzip() is None
        assert not any(
            name.lower().endswith((".1cd", ".cf", ".dt", ".exe", ".dll", ".jar", ".env"))
            for name in inner.namelist()
        )
sha = hashlib.sha256(out.read_bytes()).hexdigest()
out.with_suffix(".zip.sha256").write_text(sha + "  " + out.name + "\n", encoding="ascii")
print(
    json.dumps(
        {
            "archive": str(out),
            "bytes": out.stat().st_size,
            "payload_files": len(files),
            "sha256": sha,
            "integrity": "verified",
            "compatible_submissions": 4,
        },
        ensure_ascii=False,
        indent=2,
    )
)
