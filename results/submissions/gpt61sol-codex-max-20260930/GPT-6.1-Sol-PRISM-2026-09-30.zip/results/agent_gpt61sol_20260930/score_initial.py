import json, sys
from pathlib import Path
from windows_adapter import install, ROOT

runner = install()
from harness import orchestrate

category = sys.argv[1]
name = f"experiment_{category}_20260930_gpt61sol_codex_first"
result = orchestrate.run(ROOT / "results" / f"{name}.json", "core", runner)
result["agent_provenance"] = json.loads(
    (Path(__file__).parent / "provenance.json").read_text(encoding="utf-8")
)
out = ROOT / "results/auto" / f"{name}_auto_l1.json"
out.parent.mkdir(exist_ok=True)
out.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
for task in result["tasks"]:
    for run in task["runs"]:
        m = run["detail"].get("M", {})
        print(
            task["task_id"],
            run["scores"],
            "tests",
            m.get("passed"),
            m.get("total"),
            m.get("status", m.get("executed")),
            flush=True,
        )
        if m.get("passed") != m.get("total"):
            print("DETAIL", json.dumps(m, ensure_ascii=False), flush=True)
print("Saved", out, flush=True)
