import pathlib, subprocess, json

r = pathlib.Path("work/_onec_windows").resolve()
r.mkdir(parents=True, exist_ok=True)
bin = pathlib.Path(r"C:\Program Files\1cv8\8.3.27.2214\bin\1cv8.exe")
ib = r / "empty-ib"
cfg = r / "empty-cfg"
si = subprocess.STARTUPINFO()
si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
si.wShowWindow = 0
for name, args in [
    (
        "create",
        [
            "CREATEINFOBASE",
            f"File={ib};Locale=ru_RU;",
            "/DisableStartupDialogs",
            "/Out",
            str(r / "create.log"),
        ],
    ),
    (
        "dump",
        [
            "DESIGNER",
            "/F",
            str(ib),
            "/DumpConfigToFiles",
            str(cfg),
            "/DisableStartupDialogs",
            "/DisableStartupMessages",
            "/Out",
            str(r / "dump.log"),
        ],
    ),
]:
    p = subprocess.run(
        [str(bin), *args],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        startupinfo=si,
        creationflags=subprocess.CREATE_NO_WINDOW,
        timeout=150,
    )
    print(name, "rc", p.returncode, flush=True)
    for ext in ("log",):
        f = r / f"{name}.{ext}"
        if f.exists():
            print(f.read_text(encoding="utf-8-sig", errors="replace")[-2000:], flush=True)
    if p.returncode:
        break
print("empty configuration exists:", (cfg / "Configuration.xml").exists(), flush=True)
