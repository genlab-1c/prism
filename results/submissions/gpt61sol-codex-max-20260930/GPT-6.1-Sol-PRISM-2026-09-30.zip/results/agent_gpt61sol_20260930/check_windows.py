import json, tempfile
from pathlib import Path
from windows_adapter import install, ROOT

install()
temp_root = ROOT / "work/check_windows_temp"
temp_root.mkdir(parents=True, exist_ok=True)
tempfile.tempdir = str(temp_root)
from harness.check import run_checks
from harness.loaders import load_tasks

# Full A canonical and baseline checks are supported. B performance explicitly needs Docker/SDBL.
sections, a_ok = run_checks(category="A")
# The full B workload gate remains unavailable; run check_canonical_b.py for its S/M validation.
b_items = []
for task in sorted([t for t in load_tasks() if t.category == "B"], key=lambda t: int(t.id[1:])):
    candidates = list(temp_root.glob(f"prism_check_*/{task.id}_cm/**/native-result.json"))
    if not candidates:
        b_items.append(("skip", task.id + ": no canonical execution evidence"))
        continue
    path = max(candidates, key=lambda p: p.stat().st_mtime)
    r = json.loads(path.read_text(encoding="utf-8"))
    passed = (
        r["status"] == "ok"
        and r["total"] > 0
        and r["passed"] == r["total"]
        and not r["compile_error_lines"]
    )
    b_items.append(
        (
            "ok" if passed else "fail",
            f"{task.id}: canonical S/M {r['passed']}/{r['total']}; P/O unmeasured",
        )
    )
sections.append(
    {
        "title": "B canonical correctness from completed native runs; performance excluded",
        "items": b_items,
    }
)
b_ok = len(b_items) == 20 and all(status == "ok" for status, _ in b_items)
report = {
    "supported_checks_ok": a_ok and b_ok,
    "a_canonical_and_anchors_ok": a_ok,
    "b_canonical_correctness_ok": b_ok,
    "full_B_performance_check_complete": False,
    "reason": "Windows adapter does not implement B SDBL workload measurements",
    "sections": sections,
}
(ROOT / "work/reports/check-windows.json").write_text(
    json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
)
for section in sections:
    print(section["title"], flush=True)
    for status, text in section["items"]:
        print(status, text, flush=True)
print("SUPPORTED_CHECKS_OK", report["supported_checks_ok"], flush=True)
raise SystemExit(0 if report["supported_checks_ok"] else 1)
