import json, datetime, hashlib
from pathlib import Path
from windows_adapter import install, ROOT

runner = install()
from harness import orchestrate
from harness.generate.hashing import compute_hash

HERE = Path(__file__).resolve().parent
changed = {"A5", "B17", "B19"}
for cat in ("A", "B"):
    initial_name = f"experiment_{cat}_20260930_gpt61sol_codex_first"
    final_name = f"experiment_{cat}_20260930_gpt61sol_codex_repaired"
    data = json.loads((ROOT / "results" / f"{initial_name}.json").read_text(encoding="utf-8"))
    data["experiment_name"] = final_name
    data["agent_provenance"]["evaluation_mode"] = (
        "Codex agent; repaired three solutions after test feedback; unchanged solutions reuse original execution evidence"
    )
    data["agent_provenance"]["repaired_tasks"] = sorted(changed)
    for task in data["task_results"]:
        code = (HERE / "solutions" / f"{task['task_id']}.bsl").read_text(encoding="utf-8")
        task["runs"][0]["response"] = code
        task["runs"][0]["response_hash"] = compute_hash(code)
        if task["task_id"] in changed:
            task["runs"][0]["provenance"] = (
                "Second candidate after first hidden-test feedback; first candidate preserved separately"
            )
        else:
            assert (
                hashlib.sha256(
                    (HERE / "solutions" / f"{task['task_id']}.bsl").read_bytes()
                ).hexdigest()
                == data["agent_provenance"]["first_attempt_sha256"][task["task_id"]]
            )
    experiment = ROOT / "results" / f"{final_name}.json"
    experiment.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    result = orchestrate.run(experiment, "core", runner, task_ids=changed)
    original = json.loads(
        (ROOT / "results/auto" / f"{initial_name}_auto_l1.json").read_text(encoding="utf-8")
    )
    updated = {t["task_id"]: t for t in result["tasks"]}
    original["experiment_id"] = final_name
    original["agent_provenance"] = data["agent_provenance"]
    original["tasks"] = [updated.get(t["task_id"], t) for t in original["tasks"]]
    out = ROOT / "results/auto" / f"{final_name}_auto_l1.json"
    out.write_text(json.dumps(original, ensure_ascii=False, indent=2), encoding="utf-8")
    for task in result["tasks"]:
        r = task["runs"][0]
        print(task["task_id"], r["scores"], r["detail"]["M"], flush=True)
    print("Saved", out, flush=True)
