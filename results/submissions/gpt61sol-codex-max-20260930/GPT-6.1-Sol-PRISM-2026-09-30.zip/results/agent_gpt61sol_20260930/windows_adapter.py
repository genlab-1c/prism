from __future__ import annotations
import json, os, subprocess, sys, time, uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
os.environ["PRISM_JAVA"] = r"C:\Program Files\JetBrains\JetBrains Rider 2026.2.1\jbr\bin\java.exe"
os.environ["PRISM_BSL"] = "local"
os.environ["PRISM_RUNNER"] = "local"
os.environ["PRISM_CONCURRENCY"] = "4"
from harness.execute import runner as os_runner
from harness.execute.onec import runner as onec
from harness.execute.onec.assemble import assemble_run_config

OSCRIPT = ROOT / "tools/onescript/bin/oscript.exe"
ONEC = Path(r"C:\Program Files\1cv8\8.3.27.2214\bin\1cv8.exe")
EMPTY_CFG = ROOT / "work/_onec_windows/empty-cfg"


def hidden_process(argv: list[str], timeout: int):
    si = subprocess.STARTUPINFO()
    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow = 0
    p = subprocess.Popen(
        argv,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        startupinfo=si,
        creationflags=subprocess.CREATE_NO_WINDOW | subprocess.CREATE_NEW_PROCESS_GROUP,
    )
    try:
        stdout, stderr = p.communicate(timeout=timeout)
        return (
            p.returncode,
            stdout.decode("utf-8-sig", errors="replace"),
            stderr.decode("utf-8-sig", errors="replace"),
        )
    except subprocess.TimeoutExpired:
        subprocess.run(
            ["taskkill", "/PID", str(p.pid), "/T", "/F"],
            capture_output=True,
            startupinfo=si,
            creationflags=subprocess.CREATE_NO_WINDOW,
            timeout=15,
        )
        p.communicate(timeout=10)
        raise


class WindowsRunner(os_runner.LocalRunner):
    name: str = "windows-local-onescript-2.0.1"

    @property
    def tag(self):
        return f"windows-local:{OSCRIPT}:{OSCRIPT.stat().st_size}:wall-watchdog"

    def available(self):
        return OSCRIPT.is_file()

    def _execute(self, script, flags, timeout, stage):
        argv = [str(OSCRIPT), "-encoding=utf-8", *flags, str(script)]
        (script.parent / f"{script.name}.{stage}.command.json").write_text(
            json.dumps(argv, ensure_ascii=False), encoding="utf-8"
        )
        try:
            rc, stdout, stderr = hidden_process(argv, timeout * os_runner.WALL_FACTOR)
        except subprocess.TimeoutExpired:
            return os_runner.ExecResult(timed_out=True)
        (script.parent / f"{script.name}.{stage}.stdout.log").write_text(stdout, encoding="utf-8")
        (script.parent / f"{script.name}.{stage}.stderr.log").write_text(stderr, encoding="utf-8")
        return os_runner.ExecResult(rc=rc, stdout=stdout, stderr=stderr)

    def run_os(self, script, timeout=os_runner.TIMEOUT_S):
        return self._execute(script, [], timeout, "run")

    def check_os(self, script, timeout=os_runner.TIMEOUT_S):
        return self._execute(script, ["-check"], timeout, "check")

    def run_os_codestat(self, script, stat_path, timeout=os_runner.TIMEOUT_S):
        return self._execute(script, [f"-codestat={stat_path}"], timeout, "codestat")


def read_log(path):
    if not path.exists():
        return ""
    raw = path.read_bytes()
    return raw.decode("utf-8-sig", errors="replace")


def run_onec(candidate_code, task_dir, work_dir, entry_patterns):
    work_dir = work_dir.resolve() / ("native-" + uuid.uuid4().hex[:10])
    work_dir.mkdir(parents=True, exist_ok=True)
    entry = onec.detect_entry_point(candidate_code, entry_patterns)
    try:
        assemble_run_config(
            task_dir,
            candidate_code,
            entry or onec.ENTRY_PLACEHOLDER,
            EMPTY_CFG,
            work_dir / "run-cfg",
            result_path=str(work_dir / "result.txt"),
        )
        ib = work_dir / "ib"
        steps = [
            ("create", ["CREATEINFOBASE", f"File={ib};Locale=ru_RU;"]),
            (
                "load",
                ["DESIGNER", "/F", str(ib), "/LoadConfigFromFiles", str(work_dir / "run-cfg")],
            ),
            ("upd", ["DESIGNER", "/F", str(ib), "/UpdateDBCfg"]),
            ("check", ["DESIGNER", "/F", str(ib), "/CheckModules", "-Server"]),
        ]
        codes = {}
        for name, args in steps:
            argv = [
                str(ONEC),
                *args,
                "/DisableStartupDialogs",
                "/DisableStartupMessages",
                "/Out",
                str(work_dir / f"{name}.log"),
            ]
            (work_dir / f"{name}.command.json").write_text(
                json.dumps(argv, ensure_ascii=False), encoding="utf-8"
            )
            rc, stdout, stderr = hidden_process(argv, 180)
            codes[name] = rc
            (work_dir / f"{name}.rc").write_text(str(rc), encoding="utf-8")
            (work_dir / f"{name}.stdout.log").write_text(stdout, encoding="utf-8")
            (work_dir / f"{name}.stderr.log").write_text(stderr, encoding="utf-8")
            if name in ("create", "load") and rc:
                return onec.OneCRunResult(
                    status="infra_error",
                    entry_point=entry,
                    infra_detail=f"{name} rc={rc}: " + read_log(work_dir / f"{name}.log")[-1500:],
                )
        compile_lines, errors = onec._parse_compile_log(read_log(work_dir / "check.log"))
        if compile_lines or codes["check"]:
            return onec._verdict(work_dir, entry, False)
        if codes["upd"]:
            return onec.OneCRunResult(
                status="infra_error",
                entry_point=entry,
                infra_detail="UpdateDBCfg: " + read_log(work_dir / "upd.log")[-1500:],
            )
        if entry is None:
            return onec._verdict(work_dir, entry, False)
        argv = [
            str(ONEC),
            "ENTERPRISE",
            "/F",
            str(ib),
            "/C",
            "ПрогонТеста",
            "/DisableStartupDialogs",
            "/DisableStartupMessages",
            "/Out",
            str(work_dir / "enterprise.log"),
        ]
        (work_dir / "enterprise.command.json").write_text(
            json.dumps(argv, ensure_ascii=False), encoding="utf-8"
        )
        rc, stdout, stderr = hidden_process(argv, 90)
        (work_dir / "enterprise.rc").write_text(str(rc), encoding="utf-8")
        result = onec._verdict(work_dir, entry, False)
        result.infra_detail = (
            result.infra_detail or "Windows local 1C 8.3.27.2214; no SDBL journal collected"
        )
        (work_dir / "native-result.json").write_text(
            result.model_dump_json(indent=2), encoding="utf-8"
        )
        return result
    except subprocess.TimeoutExpired:
        return onec.OneCRunResult(
            status="infra_error",
            entry_point=entry,
            infra_detail="Windows local platform watchdog timeout",
        )
    except Exception as e:
        return onec.OneCRunResult(
            status="infra_error", entry_point=entry, infra_detail=f"{type(e).__name__}: {e}"
        )


def install():
    os_runner.OSCRIPT = OSCRIPT
    os_runner.LocalRunner = WindowsRunner
    onec.available = lambda: ONEC.is_file() and (EMPTY_CFG / "Configuration.xml").is_file()
    onec.unavailable_reason = lambda: "Windows local 1C platform or empty configuration unavailable"
    onec.run_candidate = run_onec
    from harness import orchestrate
    from harness.execute import bsl_ls

    def analyze_bytes(argv, out_dir):
        out_dir.mkdir(parents=True, exist_ok=True)
        rc, stdout, stderr = hidden_process(argv, bsl_ls.TIMEOUT_S)
        (out_dir / "analyzer.stdout.log").write_text(stdout, encoding="utf-8")
        (out_dir / "analyzer.stderr.log").write_text(stderr, encoding="utf-8")
        (out_dir / "analyzer.rc").write_text(str(rc), encoding="utf-8")
        report_path = out_dir / "bsl-json.json"
        if not report_path.exists():
            raise RuntimeError(f"BSL LS no report: rc={rc}; {stderr[-1000:]}")
        report = bsl_ls._read_json(report_path)
        return {
            bsl_ls._basename(info["path"]): [bsl_ls._norm(d) for d in info.get("diagnostics", [])]
            for info in report.get("fileinfos", [])
        }

    bsl_ls._run_and_parse = analyze_bytes
    original_o = orchestrate.SCORERS["O"]

    def optimization(task, code, protocol, work_dir, instr):
        if task.category == "B":
            return None, {
                "reason": "B performance measurement needs isolated SDBL journal; not measured by this Windows adapter",
                "leg": "O-исп-B",
            }
        return original_o(task, code, protocol, work_dir, instr)

    orchestrate.SCORERS["O"] = optimization
    orchestrate.SCORERS["P"] = lambda *args: (
        None,
        {
            "reason": "Isolated candidate SDBL journal not collected on Windows; platform axis not measured"
        },
    )
    return WindowsRunner()
